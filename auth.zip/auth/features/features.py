import hashlib
from customtkinter import *

def createPassword(text):
    return hashlib.sha256(text.encode()).hexdigest()


def messageBox(display, title, description, x, y):
    mainFont = CTkFont(('calibri',14))
    frame = CTkFrame(
        display, width=200, height=200, corner_radius=15, fg_color="#e5e5e5",bg_color="#f5f5f5"
    )
    frame.place(x=x, y=y)
    title_lbl = CTkLabel(frame, text=title)
    title_lbl.place(x=150, y=10)
    des_lbl = CTkLabel(frame, text=description,font=mainFont)
    des_lbl.place(x=100, y=100)

    btnCancel = CTkButton(
        frame,
        text="بستن",
        width=70,
        height=20,
        command=frame.place_forget,
        fg_color="red",
        text_color="white",
        hover_color="#ce6a6a"
    )
    btnCancel.place(x=50, y=150)

def messageBoxInfo(display,title,des):
    mainFont = CTkFont(('calibri',14))
    frame = CTkFrame(
        display, width=200, height=200, corner_radius=15, fg_color="#e5e5e5",bg_color="#f5f5f5"
    )
    frame.place(anchor="center",relx=0.5, rely=0.5)
    title_lbl = CTkLabel(frame, text=title)
    title_lbl.place(x=150, y=10)
    des_lbl = CTkLabel(frame, text=des,font=mainFont)
    des_lbl.place(x=100, y=100)
    
    btnCancel = CTkButton(
        frame,
        text="بستن",
        width=70,
        height=20,
        command=frame.place_forget,
        fg_color="red",
        text_color="white",
        hover_color="#ce6a6a"
    )
    btnCancel.place(anchor="s",relx=0.5, rely=0.5)
