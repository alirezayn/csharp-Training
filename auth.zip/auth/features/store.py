store = {
    "connection": 'mssql+pyodbc://./auth?driver=ODBC Driver 17 for SQL+Server'
}
user = {
    
}