from customtkinter import *
from pl.Login.Login import App
 
if __name__ == '__main__':
    root = CTk()
    root.geometry("800x400")
    set_appearance_mode("light")
    root.resizable(False,False)
    App(root)
    root.mainloop()
