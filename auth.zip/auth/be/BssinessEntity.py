from sqlalchemy import create_engine,Integer,Column,ForeignKey,String,NVARCHAR,VARCHAR
from sqlalchemy.orm import declarative_base,sessionmaker,relationship
from features.store import store
db = create_engine(store["connection"],echo=True) 
base = declarative_base()


class User(base):
    __tablename__ = "User"
    id = Column(Integer,primary_key=True)
    name = Column(NVARCHAR)
    family = Column(NVARCHAR)
    username = Column(VARCHAR)
    password = Column(String)
    role = Column(Integer)
    migration = Column(Integer)
    
    def __init__(self,name="",family="",username="",password="",role=3):
        self.name = name
        self.family= family
        self.username=username
        self.password = password
        self.role = role
     
        
# alembic init auth
# alembic revision --autogenerate -m "initial migration" برای migration
# alembic upgrade head




base.metadata.create_all(db)
