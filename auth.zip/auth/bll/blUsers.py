from dal.DAL import Repository

repos = Repository()

class blUser():
    
    def Create(self,obj):
        return repos.Create(obj)
    
    def Read(self,obj):
        return repos.Read(obj)
    
    def checkAdminExists(self,obj):
        result = self.Read(obj)
        for item in result:
            if item.role == 1:
                return True
        return False 
    
    def loginUser(self,obj,username,password):
        try:
            user = repos.ReadByUsername(obj,username)
            if user.username == username and user.password == password:
                return user
            else:
                return False
        except Exception as e:
            print(e)
            return False
        