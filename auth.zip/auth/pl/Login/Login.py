from customtkinter import *
from be.BssinessEntity import User
from bll.blUsers import blUser
from features.features import createPassword, messageBox
from pl.Admin.AdminForm import AdminApp
from pl.Support.Support import SupprotApp
from pl.Managment.Managment import ManagementApp
from tkinter import messagebox
from features.store import user

blUsers = blUser()


class App(CTkFrame):
    def __init__(self, root):
        super().__init__(root)
        self.master = root
        self.createWidgets()

    def login(self):
        password = createPassword(self.password.get())
        auth_user = blUsers.loginUser(User, self.username.get(), password)
        if auth_user == False:
            messageBox(self.master, "سلام", "دوبار اقدام کنید", 300, 100)
        elif auth_user.role == 1:
            self.loginFrame.pack_forget()
            user["name"] = auth_user.name
            AdminApp(self.master)
        elif auth_user.role == 2:
            self.loginFrame.pack_forget()
            user["name"] = auth_user.name
            ManagementApp(self.master)
        elif auth_user.role == 3:
            self.loginFrame.pack_forget()
            user["name"] = auth_user.name
            SupprotApp(self.master)

    def createAdmin(self):
        password = createPassword(self.passwordField.get())
        obj = User(
            self.nameField.get(),
            self.familyField.get(),
            self.usernameField.get(),
            password,
            1,
        )
        add_admin = blUsers.Create(obj)
        if add_admin:
            self.loginFrame.pack_forget()
            AdminApp(self.master)

    def createWidgets(self):
        users = blUsers.checkAdminExists(User)


        self.loginFrame = CTkFrame(
            self.master, width=500, height=300, fg_color="#f5f5f5", corner_radius=5
        )
        self.loginFrame.pack(anchor="center", pady=30)
        if users == False:
            self.nameField = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="name",
                placeholder_text_color="#606060",
            )
            self.nameField.place(x=100, y=10)

            self.familyField = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="family",
                placeholder_text_color="#606060",
            )
            self.familyField.place(x=100, y=70)

            self.usernameField = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="username",
                placeholder_text_color="#606060",
            )
            self.usernameField.place(x=100, y=130)

            self.passwordField = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="password",
                placeholder_text_color="#606060",
            )
            self.passwordField.place(x=100, y=200)

            self.Button = CTkButton(
                self.loginFrame,
                text="Sign up",
                width=70,
                fg_color="#0b1980",
                command=self.createAdmin,
            )
            self.Button.place(x=280, y=250)
        else:
            self.username = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="username",
                placeholder_text_color="black",
            )
            self.username.place(x=100, y=100)
            self.password = CTkEntry(
                self.loginFrame,
                width=250,
                corner_radius=5,
                border_width=0,
                fg_color="#bdbdbd",
                placeholder_text="password",
                show="*",
                placeholder_text_color="black",
            )
            self.password.place(x=100, y=150)
            self.Button = CTkButton(
                self.loginFrame,
                text="Sign in",
                width=70,
                fg_color="#0b1980",
                command=self.login,
            )
            self.Button.place(x=280, y=200)
