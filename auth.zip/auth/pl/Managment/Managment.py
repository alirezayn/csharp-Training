from customtkinter import *


class ManagementApp(CTkFrame):
    def __init__(self,root):
        super().__init__(root)
        self.createWidgets()
    def func(e):
        print("hello")

    def createWidgets(self):
        self.lable = CTkLabel(self.master,text="Management")
        self.lable.pack()
        self.master.bind("<Return>",self.func)