from customtkinter import *
from features.store import user
from features.features import createPassword, messageBoxInfo
from bll.blUsers import blUser
from be.BssinessEntity import User


users = blUser()


class AdminApp(CTkFrame):
    def __init__(self, root):
        super().__init__(root)
        self.master = root
        self.createWidgets()

    def createFrame(self):
        self.mainFont = CTkFont(("Arial", 14))
        self.AddUserFrame = CTkFrame(self.master, width=200, height=300)
        self.AddUserFrame.place(anchor="center", relx=0.5, rely=0.6)
        self.nameField = CTkEntry(
            self.AddUserFrame,
            width=180,
            border_color=None,
            placeholder_text="name",
            placeholder_text_color="black",
        )
        self.nameField.place(anchor="center", relx=0.5, rely=0.1)
        self.familyField = CTkEntry(
            self.AddUserFrame,
            width=180,
            border_color=None,
            placeholder_text="family",
            placeholder_text_color="black",
        )
        self.familyField.place(anchor="center", relx=0.5, rely=0.22)
        self.usernameField = CTkEntry(
            self.AddUserFrame,
            width=180,
            border_color=None,
            placeholder_text="username",
            placeholder_text_color="black",
        )
        self.usernameField.place(anchor="center", relx=0.5, rely=0.34)
        self.passwordField = CTkEntry(
            self.AddUserFrame,
            width=180,
            border_color=None,
            placeholder_text="password",
            placeholder_text_color="black",
        )
        self.passwordField.place(anchor="center", relx=0.5, rely=0.46)
        self.roleBox = CTkComboBox(
            self.AddUserFrame,
            values=["پشتیبان", "مدیریت پشتیبان"],
            justify="left",
            width=180,
            font=self.mainFont,
            
        )
        self.roleBox.place(anchor="center", relx=0.5, rely=0.58)

        self.btnSubmit = CTkButton(
            self.AddUserFrame,
            text="ثبت",
            fg_color="#092682",
            width=90,
            height=40,
            corner_radius=5,
            command=self.add_user,
        )
        self.btnSubmit.place(anchor="center", relx=0.75, rely=0.9)

        self.btnCancel = CTkButton(
            self.AddUserFrame,
            text="لغو",
            fg_color="#e1e1e1",
            width=90,
            height=40,
            corner_radius=5,
            text_color="black",
            hover_color="#979797",
            command=self.AddUserFrame.place_forget,
        )
        self.btnCancel.place(anchor="center", relx=0.25, rely=0.9)

    def add_user(self):
        password = createPassword(self.passwordField.get())
        if self.roleBox.get() == "مدیریت پشتیبان":
            role = 2
        elif self.roleBox.get() == "پشتیبان":
            role = 3
        obj_user = User(
            name=self.nameField.get(),
            family=self.familyField.get(),
            username=self.usernameField.get(),
            password=password,
            role=role,
        )
        result = users.Create(obj_user)
        if result:
            messageBoxInfo(self.master, "ثبت اطلاعات", "موفقیت ثبت شد")
            self.AddUserFrame.place_forget()
        else:
            messageBoxInfo(self.master, "ثبت اطلاعات", "خطایی رخ داد")

    def createWidgets(self):
        self.headerFrame = CTkFrame(self.master, height=70, width=780)
        self.headerFrame.place(x=10, y=10)
        self.btnAddPersonel = CTkButton(
            self.headerFrame,
            text="Add User",
            width=50,
            height=50,
            command=self.createFrame,
        )
        self.btnAddPersonel.place(x=700, y=10)
