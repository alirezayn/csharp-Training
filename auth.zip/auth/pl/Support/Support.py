from customtkinter import *



class SupprotApp(CTkFrame):
    def __init__(self,root):
        super().__init__(root)
        self.createWidgets()
    
    def createWidgets(self):
        self.lable = CTkLabel(self.master,text="Support")
        self.lable.pack()