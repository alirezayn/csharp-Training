from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,declarative_base
from features.store import store
base = create_engine(store["connection"])
session = sessionmaker(bind=base)()


class Repository():
    def Create(self,obj):
        try:
            session.add(obj)
            session.commit()
            return True
        except Exception as e:
            print(e)
            return False


    def Read(self,obj):
        return session.query(obj).all()
    
    def ReadByUsername(self,obj,username):
        return session.query(obj).filter(obj.username==username).first()